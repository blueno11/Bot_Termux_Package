#!/bin/bash
####################################################################
#   SCRIPT CÀI ĐẶT BOT TRÊN TERMUX
#   Chạy: bash install_termux.sh
####################################################################

echo "========================================"
echo "   DokkanBot - Install Termux"
echo "========================================"
echo ""

# Bước 1: Cài packages hệ thống
echo "[1/4] Install System Packages..."
pkg update -y
pkg install -y python libandroid-support openssl sqlcipher termux-api

echo ""
echo "NOTE:"
echo "  - For opening browser automatically, you MUST install the Termux:API app (from F-Droid)."
echo "  - After installing the app, restart Termux once."

# Bước 2: Cài thư viện Python
echo ""
echo "[2/4] Install Python Packages..."
pip install --upgrade pip

# Core libraries
pip install requests
pip install colorama
pip install beautifulsoup4
pip install pycryptodome
pip install pycryptodomex

# Prompt toolkit for arrow key history
pip install prompt_toolkit
pip install wcwidth

# SQLCipher for database decryption (optional - CLI is preferred)
pip install sqlcipher3-binary 2>/dev/null || pip install sqlcipher3 2>/dev/null || echo "Note: Python sqlcipher3 not installed (CLI will be used)"

# Orator dependencies
pip install Pygments
pip install blinker
pip install cleo==0.6.8
pip install inflection==0.3.1
pip install lazy-object-proxy
pip install pyaml==16.12.2
pip install backpack
pip install faker==0.8.18
pip install pytz
pip install pytzdata
pip install tzlocal==1.5.1
pip install python-dateutil
pip install wrapt
pip install "pendulum>=1.4,<2.0"
pip install orator --no-deps

# Bước 3: Cài pysqlsimplecipher (local module)
echo ""
echo "[3/4] Install pysqlsimplecipher..."
if [ -d "pysqlsimplecipher" ]; then
    pip install -e ./pysqlsimplecipher
    echo "✓ pysqlsimplecipher installed"
else
    echo "⚠ Warning: pysqlsimplecipher folder not found"
fi

# Bước 4: Kiểm tra
echo ""
echo "[4/4] Checking..."
python -c "import requests, colorama, orator, pendulum, Crypto, prompt_toolkit; print('✓ All libraries installed')" 2>/dev/null || echo "⚠ Some libraries may have issues"

echo ""
echo "========================================"
echo "INSTALLATION COMPLETE!"
echo "========================================"
echo ""
echo "Run bot: python launcher.py"
echo ""

